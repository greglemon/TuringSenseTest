﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class ViewControl : MonoBehaviour 
{
	public UnityEvent m_OnEnterView;
	public UnityEvent m_OnExitView;

	public void OnEnterView()
	{
		if(m_OnEnterView != null)
		{
			m_OnEnterView.Invoke();
		}
	}
	
	public void OnExitView()
	{
		if(m_OnExitView != null)
		{
			m_OnExitView.Invoke();
		}
	}
}
