﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeControl : MonoBehaviour {

	private int m_cubeSize = 50;
	private int m_cubeSpacing = 10;

	private int m_cubeStartOffsetY = -200;

	private const int kNumCubes = 10;

	private int m_cubeIndex;
	
	private const int kBeatToToggleOn = 2;
	private int m_beat;

	private GameObject[] m_cubes = new GameObject[kNumCubes];
	
	private void Start () 
	{
		Vector3 cubeSize = new Vector3(m_cubeSize, m_cubeSize, m_cubeSize);

		float cubeCollectionWidth = (m_cubeSize + m_cubeSpacing) * m_cubes.Length;
		
		float cubeStartOffsetX = -cubeCollectionWidth/2;

		float posY = transform.position.y + m_cubeStartOffsetY;
		float posZ = transform.localPosition.z;

		for(int i = 0; i < m_cubes.Length; i++)
		{
			GameObject cube = GameObject.CreatePrimitive(PrimitiveType.Cube);

			float posX = cubeStartOffsetX + ((m_cubeSize + m_cubeSpacing) * i);

			Vector3 cubePos = new Vector3(posX, posY, posZ);

        	cube.transform.position = cubePos;
			cube.transform.localScale = cubeSize;

			cube.transform.SetParent(transform, true);

			m_cubes[i] = cube;
			m_cubes[i].SetActive(false);
		}
	}

	public void ToggleCube()
	{
		m_beat++;
		if(m_beat != kBeatToToggleOn)
		{
			return;
		}

		m_beat = 0;

		if(m_cubeIndex < m_cubes.Length)
		{
			m_cubes[m_cubeIndex].gameObject.SetActive(true);
			m_cubeIndex++;
		}
		else
		{
			m_cubeIndex = 0;
			for(int i = 0; i < m_cubes.Length; i++)
			{
				m_cubes[i].SetActive(false);
			}
		}
	}
}
