﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Assertions;

public class View
{
	public RectTransform m_rectTransform;
	public ViewControl m_viewControl;

	public void OnEnterView()
	{
		if(m_viewControl != null)
		{
			m_viewControl.OnEnterView();
		}
	}

	public void OnExitView()
	{
		if(m_viewControl != null)
		{
			m_viewControl.OnExitView();
		}
	}
}

public class UIControl : MonoBehaviour {

	public float m_viewChangeSpeed = 1.0f;

	private Camera m_camera;

	private List<View> m_views = new List<View>();

	private int m_viewIndex;

	private const string kNullCamAssert = "Warning: No camera found in scene.";
	private const string kNoCanvasAssert = "Warning: {0} has no child canvas objects.";
	private const string kNoButtonsAssert = "Warning: {0} has no child button objects.";

	private float m_timer;

	private Vector3 m_lerpStart;
	private Vector3 m_lerpEnd;

	private bool m_isLerping;

	private AnimationCurve m_easeCurve;

	private void Start () 
	{
		m_camera = Camera.main;
		Assert.IsNotNull(m_camera, kNullCamAssert);
		for(int i = 0; i < transform.childCount; i++)
		{
			Transform child = transform.GetChild(i);
			RectTransform rectTransform = child.GetComponent<RectTransform>();
			if(rectTransform != null)
			{
				View view = new View();

				view.m_rectTransform = rectTransform;

				ViewControl viewControl = child.GetComponent<ViewControl>();
				if(viewControl != null)
				{
					view.m_viewControl = viewControl;
				}
				m_views.Add(view);
			}
		}
		Assert.IsTrue(m_views.Count > 0, string.Format(kNoCanvasAssert, gameObject.name));

		Button[] buttons = GetComponentsInChildren<Button>(true);
		Assert.IsTrue(buttons.Length > 0, string.Format(kNoButtonsAssert, gameObject.name));
		for(int i = 0; i < buttons.Length; i++)
		{
			Button button = buttons[i];
			button.onClick.AddListener(ToggleView);
		}
		
		Keyframe[] keys = new Keyframe[]
		{
			new Keyframe(0.0f, 0.0f),
			new Keyframe(1.0f, 1.0f)
		};
		m_easeCurve = new AnimationCurve(keys);
	}

	private void OnEnterView()
	{
		m_views[m_viewIndex].OnEnterView();
	}

	private void OnExitView()
	{
		m_views[m_viewIndex].OnExitView();
	}

	private void DriveLerp(float time)
	{
		float easeTime = m_easeCurve.Evaluate(time);
		Vector3 lerpPos = Vector3.Lerp(m_lerpStart, m_lerpEnd, easeTime);
		m_camera.transform.localPosition = lerpPos;
	}

	private void Update()
	{
		if(m_isLerping)
		{
			float modifiedDeltaTime = Time.deltaTime * m_viewChangeSpeed;
			m_timer = Mathf.Min(m_timer + modifiedDeltaTime, 1.0f);
			DriveLerp(m_timer);
			if(m_timer == 1.0f)
			{
				m_isLerping = false;
				m_timer = 0.0f;
				OnEnterView();
			}
		}	
	}

	public void ToggleView()
	{
		if(m_isLerping)
		{
			return;
		}
		
		OnExitView();

		m_viewIndex = (m_viewIndex < m_views.Count - 1) ? m_viewIndex + 1 : 0;

		Vector3 viewPos = m_views[m_viewIndex].m_rectTransform.localPosition;

		m_lerpStart = m_camera.transform.localPosition;
		m_lerpEnd = new Vector3(viewPos.x, viewPos.y, m_lerpStart.z);

		m_isLerping = true;
	}
}
