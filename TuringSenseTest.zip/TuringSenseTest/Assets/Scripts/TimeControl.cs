﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Assertions;
using UnityEngine.Events;

public class TimeControl : MonoBehaviour {

	public UnityEvent m_OnChangeSecond;
	
	public bool IsActive { get; set; }

	private Text m_text;
	private string m_dateTime;
	
	private int m_currentSecond;

	private const string kNoTextAssert = "Warning: {0} has no text component.";

	
	void Awake () 
	{
		m_text = GetComponent<Text>();
		Assert.IsNotNull(m_text, string.Format(kNoTextAssert, gameObject.name));
	}
	
	void Start()
	{
		UpdateDateTime();
	}

	void UpdateDateTimeText(string dt)
	{
		m_text.text = dt;
	}

	void UpdateDateTime(bool callOnChangeSecond = false)
	{
		System.DateTime now = System.DateTime.Now;
		int second = now.Second;
		
		if(second != m_currentSecond)
		{
			m_currentSecond = second;
			string dateTime = System.DateTime.Now.ToString("h:mm:ss tt");	
			UpdateDateTimeText(dateTime);
			if(callOnChangeSecond && m_OnChangeSecond != null)
			{
				m_OnChangeSecond.Invoke();
			}
		}
	}

	void Update () 
	{
		if(!IsActive)
		{
			return;
		}
		UpdateDateTime(true);	
	}
}
